#ifndef MOONSHINE_C_API_H
#define MOONSHINE_C_API_H

/* Moonshine is a library for building interactive voice applications. It
   provides a high-level API for building voice interfaces, including
   voice-activity detection, diarization, transcription, speech understanding,
   and text-to-speech. It is designed to be fast, easy to use and to provide a
   high level of accuracy. It is also designed to be easy to integrate into your
   existing codebase across all major platforms.

   It uses the Moonshine family of speech to text models, which:

     - Understand multiple major languages, including English, Japanese,
       Korean, Chinese, Arabic, and more.

     - Are designed to be lightweight and fast for mobile and edge devices,
       and can be used in the cloud where latency and compute costs matter.

     - Support streaming transcription to reduce latency on real-time
       applications.

     - Are trained from scratch on a large, unique dataset of audio data,
       allowing our team to quickly train custom models for jargon or dialects.

     - Are available under permissive licenses, with English fully MIT
       licensed and other languages under a non-commercial agreement.

   You'll most likely want to use the specific bindings for your language of
   choice, since this is a low-level C API to the underlying implementation.
   This is the interface that those bindings all use though, so if you're
   interested in porting to a new environment or language, the inline notes
   here may be useful.

   Here's an example of how to use the transcriber:
   ```c
   #include "moonshine-c-api.h"

   int main(int argc, char *argv[]) {
     int32_t transcriber_handle = moonshine_load_transcriber_from_files(
       "path/to/models", MOONSHINE_MODEL_ARCH_BASE, NULL, 0,
       MOONSHINE_HEADER_VERSION);
     if (transcriber_handle < 0) {
       fprintf(stderr, "Failed to load transcriber\n");
       return 1;
     }

     float audio_data[32000] = {};
     size_t audio_length = 32000;
     int32_t sample_rate = 16000;
     transcript_t *transcript = NULL;
     int32_t error = moonshine_transcribe_without_streaming(transcriber_handle,
   audio_data, audio_length, sample_rate, 0, &transcript); if (error != 0) {
       fprintf(stderr, "Failed to transcribe\n");
       return 1;
     }
     for (size_t i = 0; i < transcript->line_count; i++) {
       printf( "Line %zu at %f seconds: %s\n", i, transcript->lines[i].start,
         transcript->lines[i].text);
     }
     moonshine_free_transcriber(transcriber_handle);
     return 0;
   }

   All API calls are thread-safe, so you can call them from multiple threads
   concurrently. Calculations on a single transcriber will be serialized
   however, so latency will be affected for calls from other threads while
   the transcriber is busy.
   ```
*/

#if defined(ANDROID)
#include <android/asset_manager.h>
#endif
#include <stddef.h>
#include <stdint.h>

#ifdef _WIN32
#define MOONSHINE_EXPORT __declspec(dllexport)
#else
#define MOONSHINE_EXPORT __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------ CONSTANTS -------------------------------- */

/* What version of the Moonshine library the header file is associated with.
   You should pass this version to moonshine_load_transcriber so that newer
   versions of the library can emulate any older behavior that has changed.
   The format is MAJOR * 10000 + MINOR * 100 + PATCH.
   For example, version 3.0.0 would be 30000.
   For example, version 3.2.7 would be 30207.                                */
#define MOONSHINE_HEADER_VERSION (30000)

/* The first header version that no longer supports
   moonshine_load_transcriber_from_memory. A client passing this version or
   newer gets MOONSHINE_ERROR_INVALID_ARGUMENT back from that call, along with
   a logged explanation, and should use
   moonshine_load_transcriber_from_memory_files instead. Clients built against
   an earlier header keep the old behavior, so existing binaries are
   unaffected.                                                               */
#define MOONSHINE_FROM_MEMORY_REMOVED_VERSION (30000)

/* Supported model architectures.                                            */
#define MOONSHINE_MODEL_ARCH_TINY (0)
#define MOONSHINE_MODEL_ARCH_BASE (1)
#define MOONSHINE_MODEL_ARCH_TINY_STREAMING (2)
/* Note: BASE_STREAMING is defined for future use but is not currently
   published in the model catalog.                                           */
#define MOONSHINE_MODEL_ARCH_BASE_STREAMING (3)
#define MOONSHINE_MODEL_ARCH_SMALL_STREAMING (4)
#define MOONSHINE_MODEL_ARCH_MEDIUM_STREAMING (5)

/* Error codes.                                                            */
#define MOONSHINE_ERROR_NONE (0)
#define MOONSHINE_ERROR_UNKNOWN (-1)
#define MOONSHINE_ERROR_INVALID_HANDLE (-2)
#define MOONSHINE_ERROR_INVALID_ARGUMENT (-3)
/* A streaming generation is in flight and the call would have competed with it
   for the model. Finish it, or call moonshine_tts_cancel.                   */
#define MOONSHINE_ERROR_BUSY (-4)

/* Statuses from moonshine_tts_next_chunk. All are positive, so the usual
   "negative means failure" test still separates them from real errors, and
   all convert with moonshine_error_to_string.                              */
/* No complete sentence is buffered yet. Push more text, or flush.          */
#define MOONSHINE_TTS_NEED_TEXT (1)
/* Input ended and every queued utterance has been synthesized.             */
#define MOONSHINE_TTS_END_OF_STREAM (2)
/* moonshine_tts_cancel discarded the reply that was being generated. Sent
   once, and only when there was something to discard, so a consumer pulling
   chunks on a worker thread can tell an interruption from running out of
   text.                                                                    */
#define MOONSHINE_TTS_CANCELLED (3)

/* Flags.                                                                */
#define MOONSHINE_FLAG_FORCE_UPDATE (1 << 0)
/* Apply alphanumeric-spelling fusion to every completed line in the
   returned transcript. The transcriber must have been constructed with
   a spelling model (either ``spelling_model_path`` in
   moonshine_load_transcriber_from_files or a non-null
   ``spelling_model_data`` buffer in
   moonshine_load_transcriber_from_memory) for this flag to have any
   effect; if no spelling model is loaded, the flag is ignored.

   When fusion fires for a line, the line's ``text`` field is *replaced*
   with the resolved single character (e.g. ``"a"`` or ``"$"``). Speech
   that does not resolve to a character is left unchanged so command
   words like "stop" / "clear" / "delete" can still be classified by
   higher-level Python code. */
#define MOONSHINE_FLAG_SPELLING_MODE (1 << 1)

/* --------------------------- DATA STRUCTURES ----------------------------- */

/* Values passed to moonshine_load_transcriber,
   moonshine_create_text_to_speech_synthesizer or
   moonshine_create_graph_to_phonemizer at creation time that control
   the behavior of the transcriber. A typical use case would be to specify
   model configuration options like layer names that vary by language. The
   value is a string. You don't normally need to care about these, this is just
   for advanced customizations.                                              */
struct moonshine_option_t {
  const char *name;
  const char *value;
};

/* All transcription calls return a list of "lines". These line objects
represent a piece of speech, something like a sentence or phrase. For
non-streaming calls, you get back a finalized list of these lines, with all
their states set to “complete”. Each streaming call returns a similar list, but
if there isn’t a pause at the end of the current audio - if the user still
seems to be speaking but cut off - the final line will be marked as being
incomplete.

All memory referenced by the line objects is owned by the transcriber and is
valid until the next call to that transcriber, or until the transcriber is
freed.

The audio data is 16KHz float PCM, between -1.0 and 1.0.

To make the streaming results easier to work with we offer some guarantees:

 - Lines are never removed from the results, only added.

 - Only the last line in the list may potentially be incomplete.

 - If speech is detected by the VAD, but no transcription can be produced, the
   line will be an empty string, "".

 - Line indexes can be used as stable references when repeatedly calling
   streaming transcription. This means a client can remember the length of the
   last results returned, and when it calls again it can figure out the updates
   by iterating the results starting at that line index.

 - The line id is a stable identifier for the line. This is set to a 64-bit
   randomly-generated number, with the goal of minimizing the chances of a
   collision. Currently these IDs are in ascending order in any one transcript,
   but this is not guaranteed and should not be relied on.

 - When speaker identification is enabled (the opt-in ``identify_speakers``
   option), each line carries an array of speaker spans describing who was
   talking during which parts of the line, including UTF-8 character ranges
   into the line text. Word timestamps are enabled automatically in this mode.
   Speaker IDs are 64-bit
   randomly-generated numbers that are stable for a given speaker within a
   stream, and speaker indices count speakers in order of first appearance.
   Unlike the text and timing of a line, speaker spans for recent audio are
   *mutable*: streaming diarization re-clusters a sliding window
   (``diarization_cluster_window_sec``, default 120s) as more speech arrives;
   assignments for older audio are frozen. The ``have_speakers_changed`` flag is
   set on a line whenever its spans changed since the previous call.

See the stream transcription examples below for more details on what this
means in practice.
*/

/* A single word with timing information.
   Only populated when word_timestamps option is enabled. */
struct transcript_word_t {
  /* UTF-8-encoded word text. */
  const char *text;
  /* Start time in seconds (absolute, from start of audio/stream). */
  float start;
  /* End time in seconds. */
  float end;
  /* Model confidence score, 0.0 to 1.0. */
  float confidence;
};

/* One contiguous span of speech within a line attributed to a single
   speaker. Only populated when the identify_speakers option is enabled.
   Spans can be revised on any transcription call, even for lines that are
   already complete; see the have_speakers_changed flag on
   transcript_line_t. Character ranges use UTF-8 byte offsets into the line
   text; word_timestamps are enabled automatically when identify_speakers is
   on. */
struct speaker_span_t {
  /* Time offset from the start of the array or stream in seconds. */
  float start_time;
  /* Length of the span in seconds. */
  float duration;
  /* Stable identifier for the speaker within this stream. */
  uint64_t speaker_id;
  /* The order the speaker first appeared in the transcript, starting at 0. */
  uint32_t speaker_index;
  /* UTF-8 byte offset into the line's text where this span begins (inclusive).
     Only meaningful when identify_speakers is enabled; word_timestamps are
     turned on automatically in that case. Both zero when unknown. */
  uint64_t start_char;
  /* UTF-8 byte offset into the line's text where this span ends (exclusive).
     Both zero when unknown. */
  uint64_t end_char;
};

/* Information about a single “line” of a transcript. */
struct transcript_line_t {
  /* UTF-8-encoded transcription. */
  const char *text;
  /* The audio data for the current phrase. */
  const float *audio_data;
  /* The number of elements in the audio data array. */
  size_t audio_data_count;
  /* Time offset from the start of the array or stream in seconds.  */
  float start_time;
  /* How long the segment currently is in seconds. */
  float duration;
  /* Stable identifier for the line. */
  uint64_t id;
  /* Streaming-only: Zero means the speaker hasn't finished talking in this
   * segment, non-zero means they have. */
  int8_t is_complete;
  /* Streaming-only: Whether the line has been updated since the previous call
   * to moonshine_transcribe_stream. */
  int8_t is_updated;
  /* Streaming-only: Whether the line was newly added since the previous call to
   * moonshine_transcribe_stream. */
  int8_t is_new;
  /* Streaming-only: Whether the text of the line has changed since the previous
   * call to moonshine_transcribe_stream. */
  int8_t has_text_changed;
  /* Whether the speaker spans of the line have changed since the previous
   * call to moonshine_transcribe_stream. Unlike the other change flags, this
   * can fire for lines that are already complete, since diarization refines
   * speaker assignments retroactively as more audio arrives. */
  int8_t have_speakers_changed;
  /* Speaker spans covering this line, ordered by start time and clipped to
   * the line's time range. NULL unless the identify_speakers option is
   * enabled and speech has been attributed to a speaker. */
  const struct speaker_span_t *speaker_spans;
  /* Number of entries in the speaker_spans array. */
  uint64_t speaker_span_count;
  /* Streaming-only: The latency of the last transcription in milliseconds. */
  uint32_t last_transcription_latency_ms;
  /* Word-level timestamps. NULL if word_timestamps option is not enabled. */
  const struct transcript_word_t *words;
  /* Number of words in the words array. 0 if not enabled. */
  uint64_t word_count;
};

/* An entire transcription of an audio data array or stream.                 */
struct transcript_t {
  struct transcript_line_t *lines; /* All lines of the transcript. */
  uint64_t line_count;             /* Number of lines in the transcript.      */
};

/* ------------------------------ FUNCTIONS -------------------------------- */

/* Returns the loaded moonshine library version. This may be different from
   the header version if a newer shared library is loaded.
*/
MOONSHINE_EXPORT int32_t moonshine_get_version(void);

/* Converts an error code number returned from an API call into a
   human-readable string. */
MOONSHINE_EXPORT const char *moonshine_error_to_string(int32_t error);

/* Frees a buffer that a moonshine_* function documented as "allocated with
   malloc; release with free" returned to the caller. This covers, for
   example, ``out_audio_data`` from moonshine_text_to_speech /
   moonshine_phonemes_to_speech, the JSON / comma-separated strings from
   moonshine_get_tts_dependencies / moonshine_get_g2p_dependencies /
   moonshine_get_tts_voices, and ``out_phonemes`` from
   moonshine_text_to_phonemes.

   Always use this instead of the C runtime ``free`` directly. On Windows the
   library and its host (e.g. a Python binding) can be linked against
   different C runtimes with independent heaps, so freeing a library-allocated
   pointer with the host's ``free`` corrupts the heap. Routing the free back
   through the library guarantees the allocation and deallocation happen in
   the same runtime. Safe to call on NULL. */
MOONSHINE_EXPORT void moonshine_free_buffer(void *ptr);

/* Replaces the contextual-biasing key terms on an existing transcriber, so a
   caller can follow whatever context the user is in - the contact list on
   screen, the vocabulary of the document being dictated into - without
   reloading the model. ``keyterms`` is a comma-separated list using the same
   syntax as the ``keyterms`` load option; pass NULL or an empty string to turn
   biasing off.

   Safe to call between transcribe calls on a live stream. Takes effect on the
   next transcribe call: it does not retroactively change text already emitted.

   Returns ``MOONSHINE_ERROR_NONE`` on success, or a non-zero error code if the
   handle is invalid or the loaded model is not a streaming architecture (only
   those decode through a path that can apply the bias). */
MOONSHINE_EXPORT int32_t moonshine_transcriber_set_keyterms(
    int32_t transcriber_handle, const char *keyterms);

/* Picks the key terms out of a passage of free-form text and biases towards
   them, replacing any previous list. Where
   ``moonshine_transcriber_set_keyterms`` wants a list, this wants context: hand
   over the document on screen, the agenda for the meeting, the last few
   messages in the thread, and the unusual words in it are found for you.

   A word is judged unusual by how the model's own tokenizer spells it. That
   vocabulary is ordered by frequency, so an everyday word has a token to itself
   while jargon and proper nouns have to be built out of several subwords, and
   needing more than one is the signal used here. It follows the language of the
   loaded model, and the capitalization in the passage is what gets asked for in
   the transcript.

   ``max_terms`` caps the list; pass 0 for the default of 200. The cap matters:
   a long list costs accuracy on the words you did not ask for (see
   docs/models/domain-customization.md), so the terms the passage leans on
   hardest are kept and the rest of its long tail is dropped. Pass NULL or an
   empty string to turn biasing off.

   Safe to call between transcribe calls on a live stream. Takes effect on the
   next transcribe call: it does not retroactively change text already emitted.

   Returns ``MOONSHINE_ERROR_NONE`` on success, or a non-zero error code if the
   handle is invalid or the loaded model is not a streaming architecture (only
   those decode through a path that can apply the bias). */
MOONSHINE_EXPORT int32_t moonshine_transcriber_set_context(
    int32_t transcriber_handle, const char *context, int32_t max_terms);

/* Converts a transcript_t struct into a human-readable string for debugging
 * purposes. The string is owned by the library, and is valid until the next
 * call to moonshine_transcript_to_string. */
MOONSHINE_EXPORT const char *moonshine_transcript_to_string(
    const struct transcript_t *transcript);

/* Loads models from the file system, using `path` as the root directory. The
   implementation expects the following files to be present in the directory:
   - encoder_model.ort
   - decoder_model_merged.ort
   - tokenizer.bin
   The .ort files are quantized activation ONNX models that have been converted
   to ORT format using the onnxruntime tools. The simplest way to obtain these
   files is to run the `scripts/download-moonshine-model.py` script, for
   example `python scripts/download-moonshine-model.py --model-type base
   --model-language en`.
   The source weights are available on the Hugging Face Model Hub at
   https://huggingface.co/moonshine-ai/, and the download and conversion to
   ONNX script is available in this repository at
   `scripts/convert-moonshine-model.sh`.
   The tokenizer.bin contains the token to character mapping for the model,
   in a compact binary format. The `scripts/json-to-bin-vocab.py` can be used
   to convert common tokenizer.json files to tokenizer.bin files.

   The `model_arch` parameter is used to select the model architecture, for
   example MOONSHINE_MODEL_ARCH_BASE or MOONSHINE_MODEL_ARCH_TINY_STREAMING.

   The `options` parameter is used to set any custom options for the
   transcriber. Recognized options include ``log_ort_run`` (bool),
   ``ort_providers`` (comma-separated execution provider names such as
   ``CoreML,CPU`` on macOS; default and recommendation is CPU-only, and the
   iOS and Android libraries ship with no other choice — see
   docs/execution-providers.md), and ``coreml_cache_dir`` (directory for the
   CoreML compiled model cache on macOS).
   Pass ``use_speculative_decoding`` (bool, default true) to control
   speculative re-decode of the previous hypothesis on streaming updates
   (set false to fall back to greedy redecode from BOS).
   Pass ``decode_incomplete_lines`` (bool, default true) to run the
   decoder on in-progress lines so the transcript can update while someone
   is still talking. Set false to encode (and diarize) as audio arrives
   but wait until the line is complete before decoding.
   Pass ``keyterms`` (comma-separated terms, e.g.
   ``Kubernetes,Anushka Sharma,ANSI/ISO``) to bias the decoder towards words it
   would otherwise be unlikely to produce - jargon, product names, contact
   names. No retraining is involved: each term is compiled into a subword trie
   and used to nudge the decoder's logits, so the terms can be different on
   every transcriber and can be replaced mid-stream with
   ``moonshine_transcriber_set_keyterms``. Match the capitalization and
   spelling you want to see in the output. Only the streaming architectures
   apply this. Pass ``context`` instead (or as well) to hand over a passage of
   free-form text and have the terms picked out of it, as
   ``moonshine_transcriber_set_context`` does, with ``context_max_terms``
   (int, default 200) capping how many are taken.
   ``keyterm_boost`` (float, default 2.0) sets the strength. The
   default is where the terms come out most accurately; going higher recovers no
   more of them and starts putting them where they were not said, so lower it if
   general accuracy matters more than the list does, rather than raising it.
   Pass ``identify_speakers`` (bool, default false) to enable speaker
   diarization: each line then carries a ``speaker_spans`` array describing
   who spoke when, including UTF-8 character ranges into the line text.
   This also enables word timestamps automatically. This runs the cpp-annote
   diarization pipeline (a port of
   pyannote community-1) inline inside transcription calls, which adds
   significant compute, and re-clustering cost grows with session length unless
   bounded by ``diarization_cluster_window_sec``.
   ``diarization_cluster_cadence`` (float seconds, default 2.0) sets the
   minimum interval between re-clustering passes - raise it to reduce cost on
   long sessions - ``diarization_analyze_cadence`` (float seconds,
   default 0 = model default of 1.0) sets the sliding-window step between
   segmentation/embedding model runs (live ``add_audio`` / transcribe runs at
   most one window per call; Stop drains the rest; silent speaker classes skip
   embedding inference), and ``diarization_cluster_window_sec``
   (float seconds, default 120.0) limits how much audio history VBx
   re-clustering considers on each refresh (0 = unlimited full history).
   Pass ``"spelling_model_path"`` with a path to a
   spelling-CNN ``.ort`` file (e.g.
   ``https://download.moonshine.ai/model/spelling-en/spelling_cnn.ort``)
   to enable alphanumeric spelling fusion via
   ``MOONSHINE_FLAG_SPELLING_MODE``; if not set, the spelling model is
   not loaded and the flag is a no-op.

   The `options_count` parameter is the number of options in the options array.

   The `moonshine_version` parameter should be set to MOONSHINE_HEADER_VERSION
   to ensure that if a newer version of the library is loaded, it emulates the
   behavior of the older version to ensure compatibility.

   The return value is a handle to a transcriber, which can be used to identify
   the transcriber in subsequent calls. If there was an error, a negative value
   is returned. This code can be converted to a human-readable string using
   moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_load_transcriber_from_files(
    const char *path, uint32_t model_arch,
    const struct moonshine_option_t *options, uint64_t options_count,
    int32_t moonshine_version);

/* **DEPRECATED** Use moonshine_load_transcriber_from_memory_files instead.
   This function is deprecated and will be removed in a future version.

   Callers that pass a `moonshine_version` of
   MOONSHINE_FROM_MEMORY_REMOVED_VERSION or newer are refused: the call logs an
   explanation and returns MOONSHINE_ERROR_INVALID_ARGUMENT without loading
   anything. Only clients built against an earlier header, which pass that
   earlier version here, can still use it.

   Loads models from memory. The `encoder_model_data`, `decoder_model_data` and
   `tokenizer_data` parameters are the data arrays for the models in binary
   format, and are expected to be in the same format as the files disk.

   `spelling_model_data` and `spelling_model_data_size` are an optional
   in-memory ``.ort`` payload for the alphanumeric spelling-CNN. Pass
   ``NULL`` and ``0`` if you don't want spelling fusion. When provided,
   the buffer must outlive the transcriber (it is *not* copied) and the
   transcriber will run spelling fusion whenever
   ``MOONSHINE_FLAG_SPELLING_MODE`` is passed to
   ``moonshine_transcribe_stream`` or
   ``moonshine_transcribe_without_streaming``.

   All of the other parameters are the same as for
   moonshine_load_transcriber_from_files.                                    */
MOONSHINE_EXPORT int32_t moonshine_load_transcriber_from_memory(
    const uint8_t *encoder_model_data, size_t encoder_model_data_size,
    const uint8_t *decoder_model_data, size_t decoder_model_data_size,
    const uint8_t *tokenizer_data, size_t tokenizer_data_size,
    const uint8_t *spelling_model_data, size_t spelling_model_data_size,
    uint32_t model_arch, const struct moonshine_option_t *options,
    uint64_t options_count, int32_t moonshine_version);

/* Loads a transcriber from a set of in-memory model assets keyed by their
   canonical filename. This is the in-memory counterpart that reaches full
   parity with moonshine_load_transcriber_from_files: unlike
   moonshine_load_transcriber_from_memory (which only accepts a fixed
   encoder/decoder/tokenizer/spelling set and rejects streaming models), this
   entry point accepts whatever files the chosen architecture needs, resolved
   by name.

   ``filenames[i]`` is the canonical filename as it would appear on disk under
   a model directory. Recognized keys depend on ``model_arch``:
     - Non-streaming (TINY, BASE): ``encoder_model.ort``,
       ``decoder_model_merged.ort``, ``tokenizer.bin`` (all required), plus the
       optional word-timestamp decoder ``decoder_with_attention.ort`` (or the
       two-pass ``alignment_model.ort``) when the ``word_timestamps`` option is
       set.
     - Streaming (``*_STREAMING``): ``frontend.ort`` (or the split pair
       ``frontend.model.ort`` + ``frontend.weights.ort``), ``encoder.ort``,
       ``adapter.ort``, ``cross_kv.ort``, ``decoder_kv.ort``,
       ``streaming_config.json``, ``tokenizer.bin`` (all required), plus the
       optional ``decoder_kv_with_attention.ort`` when ``word_timestamps`` is
       set.
     - Either kind also accepts ``spelling_cnn.ort``, and the two diarization
       models ``segmentation.ort`` and ``embedding.ort``, which are required
       when the ``identify_speakers`` option is set. Fetch those two with
       moonshine_get_diarization_dependencies.
   Unrecognized keys are rejected with MOONSHINE_ERROR_INVALID_ARGUMENT, and
   missing required keys cause the load to fail. The recognized set is the
   union of the names above across every architecture, so passing an asset
   this architecture or option set has no use for is fine - handing over a
   whole downloaded model directory works - but a misspelled name is reported
   against the key you passed instead of surfacing later as a missing-asset
   failure.

   When ``memory[i]`` is non-NULL and ``memory_sizes[i]`` > 0, that buffer is
   used as the asset bytes. The library does not copy the model buffers (the
   ONNX Runtime sessions read them directly), so the buffers must outlive the
   transcriber, exactly as for moonshine_load_transcriber_from_memory. When
   ``memory[i]`` is NULL or ``memory_sizes[i]`` is zero, ``filenames[i]`` is
   also used as a filesystem path (relative to the current working directory
   unless absolute), so callers can mix in-memory and on-disk assets.

   All other parameters behave as in the other transcriber loaders. Returns a
   non-negative handle on success, or a negative error code on failure. */
MOONSHINE_EXPORT int32_t moonshine_load_transcriber_from_memory_files(
    const char **filenames, const uint8_t **memory,
    const uint64_t *memory_sizes, uint64_t file_count, uint32_t model_arch,
    const struct moonshine_option_t *options, uint64_t options_count,
    int32_t moonshine_version);

/* Releases all resources used by the transcriber. Subsequent transcriber
   creation calls may reuse this transcriber's ID, so ensure you remove
   all references to it in your client code after freeing it.*/
MOONSHINE_EXPORT void moonshine_free_transcriber(int32_t transcriber_handle);

/* Given an array of PCM audio data, identifies sections of speech and
   transcribes them into text. This is the call to use if you're analyzing audio
   from a file or other static source where you have all the audio data at once.
   If you are transcribing audio from a live microphone or other real-time
   source, you should use the streaming API instead, since it offers lower
   latency for those use cases.

   `transcriber_handle` should be a handle to a transcriber returned by
    moonshine_load_transcriber_from_files or
    moonshine_load_transcriber_from_memory.

   `audio_data` should be a pointer to an array of PCM audio data, between -1.0
    and 1.0, at a sample rate of `sample_rate` Hz. Internally the library uses
    16,000 Hz, so to avoid resampling you should capture audio at this rate if
    possible.

   `audio_length` should be the number of samples in the audio data array.

   `sample_rate` should be the sample rate of the audio data, in Hz.
   `flags` should be a bitwise OR of flags. Currently the only supported flag
   is MOONSHINE_FLAG_SPELLING_MODE, which applies alphanumeric-spelling fusion
   to completed lines (requires the transcriber to have been loaded with a
   spelling model; otherwise the flag is a no-op). Pass zero for the default
   behavior.

   `out_transcript` should be a pointer to a pointer to a transcript_t struct.
   The transcript_t struct will be populated with the transcript data, which
   consists of a list of lines, each with text, audio data, and timestamps.
   This data is owned by the transcriber and is valid until the next call to
   that transcriber, or until the transcriber is freed.

   The return value is zero on success, or a non-zero error code on failure.
   The error code can be converted to a human-readable string using
   moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_transcribe_without_streaming(
    int32_t transcriber_handle, float *audio_data, uint64_t audio_length,
    int32_t sample_rate, uint32_t flags, struct transcript_t **out_transcript);

/* Streaming allows the library to incrementally return updated results as
   new audio data becomes available in real-time. This approach allows us to
   produce results with lower latency than non-streaming approaches, by
   reusing calculations done on earlier audio data.

   The `transcriber_handle` should be a handle to a transcriber returned by
   moonshine_load_transcriber_from_files or
   moonshine_load_transcriber_from_memory. A single transcriber can have
   multiple streams associated with it, and each stream can be used to
   transcribe a separate audio stream.

   The `flags` should be a bitwise OR of flags. None are currently supported so
   this should always be zero.

   The return value is a handle to a stream, which can be used to identify the
   stream in subsequent calls. If there was an error, a negative value is
   returned. The error code can be converted to a human-readable string using
   moonshine_error_to_string.

   Below is some pseudocode showing an example of how to use streaming. In a
   real application you'll want to check the return value of the functions and
   handle errors appropriately. `get_audio_from_microphone` stands in for your
   capture loop: feed each chunk to
   moonshine_transcribe_add_audio_to_stream (safe from an audio callback),
   then call moonshine_transcribe_stream on another thread when you want an
   updated transcript. A more complete example is the streaming test in
   core/moonshine-c-api-test.cpp.

   ```c
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        "path/to/models", MOONSHINE_MODEL_ARCH_BASE, NULL, 0,
        MOONSHINE_HEADER_VERSION);
    int32_t stream_handle = moonshine_create_stream(transcriber_handle, 0);
    moonshine_start_stream(transcriber_handle, stream_handle);

    float* latest_audio_data;
    size_t latest_audio_data_length;
    while (get_audio_from_microphone(&latest_audio_data,
      &latest_audio_data_length)) {
      moonshine_transcribe_add_audio_to_stream(transcriber_handle,
        stream_handle, latest_audio_data, latest_audio_data_length,
       microphone_sample_rate, 0);
      if (time_since_last_transcription < min_time_between_transcriptions) {
        continue;
      }
      transcript_t *partial_transcript = NULL;
      moonshine_transcribe_stream(transcriber_handle,
        stream_handle, 0, &partial_transcript);
      printf("%s\n", moonshine_transcript_to_string(partial_transcript));
    }
    moonshine_stop_stream(transcriber_handle, stream_handle);

    transcript_t *final_transcript = NULL;
    moonshine_transcribe_stream(transcriber_handle, stream_handle, 0,
      &final_transcript);
    printf("%s\n", moonshine_transcript_to_string(final_transcript));

    moonshine_free_stream(transcriber_handle, stream_handle);
    moonshine_free_transcriber(transcriber_handle);
    ```

   The transcripts that are returned consist of a list of lines, each with
   text, audio data, timestamp, duration, and other metadata. This metadata
   includes an `is_updated` flag, which is set to 1 if the line has been updated
   since the last call to moonshine_transcribe_stream. You can use this as a
   "dirty flag" to determine how to update your UI in a minimal way, touching
   only the elements that have changed. Updated lines only appear at the end of
   the list of lines, and once the `is_complete` flag is set to 1 for a line,
   its text and timing will never change again.

   The one exception is speaker information: when the `identify_speakers`
   option is enabled, speaker spans for recent audio can be revised on any call
   to moonshine_transcribe_stream, since diarization re-clusters a sliding
   window of recent speech. Older assignments are frozen. Watch the
   `have_speakers_changed` flag to detect these revisions.
*/

/* Creates a stream. This function returns a handle to the stream, which can be
   used to identify the stream in subsequent calls. If there was an error, a
   negative value is returned. The error code can be converted to a
   human-readable string using moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_create_stream(int32_t transcriber_handle,
                                                 uint32_t flags);

/* Releases the resources used by a stream.
   Subsequent stream creation calls may reuse this stream's ID, so ensure you
   remove all references to it in your client code after freeing it.*/
MOONSHINE_EXPORT int32_t moonshine_free_stream(int32_t transcriber_handle,
                                               int32_t stream_handle);

/* Starts a stream. This should be called before adding audio or calling
   moonshine_transcribe_stream. Start/stop are supported because there may
   sometimes be a discontinuity in the audio input, for example when the user
   mutes their input, so we need a way to start fresh after a break like this.
   This function returns zero on success, or a non-zero error code on failure.
   The error code can be converted to a human-readable string using
   moonshine_error_to_string.
 */
MOONSHINE_EXPORT int32_t moonshine_start_stream(int32_t transcriber_handle,
                                                int32_t stream_handle);

/* Stops a stream. Further moonshine_transcribe_add_audio_to_stream calls are
   rejected, but audio that has not yet been analyzed is kept. Call
   moonshine_transcribe_stream afterwards to drain that leftover audio and get
   the final transcript, with all lines marked complete. This function returns
   zero on success, or a non-zero error code on failure. The error code can be
   converted to a human-readable string using moonshine_error_to_string.
 */
MOONSHINE_EXPORT int32_t moonshine_stop_stream(int32_t transcriber_handle,
                                               int32_t stream_handle);

/* Call this when new audio data becomes available from your microphone or other
   audio source. This function will add the audio data to the stream's buffer,
   but it will not transcribe it or do any other processing, so this should be
   safe to call frequently even from time-critical threads. The size of the
   input audio doesn't have any impact on performance, so you should call this
   with whatever the natural chunk size is for your audio source. It is up to
   you to call moonshine_transcribe_stream when you want an updated transcript,
   the frequency of which should be determined by your application's latency and
   compute budgets.

   `transcriber_handle` should be a handle to a transcriber returned by
   moonshine_load_transcriber_from_files or
   moonshine_load_transcriber_from_memory.

   `stream_handle` should be a handle to a stream returned by
   moonshine_create_stream.

   `new_audio_data` should be a pointer to an array of PCM audio data, between
   -1.0 and 1.0, at a sample rate of `sample_rate` Hz. `audio_length` should be
   the number of samples in the audio data array.

   `sample_rate` should be the sample rate of the audio data, in Hz.

   `flags` should be a bitwise OR of flags. None are currently supported so
   this should always be zero.

   The return value is zero on success, or a non-zero error code on failure.
   The error code can be converted to a human-readable string using
   moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_transcribe_add_audio_to_stream(
    int32_t transcriber_handle, int32_t stream_handle,
    const float *new_audio_data, uint64_t audio_length, int32_t sample_rate,
    uint32_t flags);

/* Analyzes all the audio data in the stream and returns an updated transcript
   of all the speech segments found. By default this function will only perform
   full analysis on the audio data if there has been more than 200ms of new
   samples since the last complete analysis. This is to ensure that too-frequent
   calls to this function don't result in poor performance. This can be
   overridden by setting the MOONSHINE_FLAG_FORCE_UPDATE flag.

   After moonshine_stop_stream, leftover audio is analyzed even if it is
   shorter than that interval, so the stop-then-transcribe_stream sequence in
   the example above produces a complete transcript. You do not need
   MOONSHINE_FLAG_FORCE_UPDATE for that final call, and you do not need to
   have pulled partial transcripts first.

   `transcriber_handle` should be a handle to a transcriber returned by
   moonshine_load_transcriber_from_files or
   moonshine_load_transcriber_from_memory.

   `stream_handle` should be a handle to a stream returned by
   moonshine_create_stream.

   `flags` should be a bitwise OR of flags. Currently the only supported flag is
   MOONSHINE_FLAG_FORCE_UPDATE, which ignores the time-based caching logic to
   ensure the stream is fully analyzed by the models.

   `out_transcript` should be a pointer to a pointer to a transcript_t struct.
   The transcript_t struct will be populated with the transcript data, which
   consists of a list of lines, each with text, audio data, and timestamps.
   This data is owned by the transcriber and is valid until the next call to
   that transcriber, or until the transcriber is freed.

   The return value is zero on success, or a non-zero error code on failure.
   The error code can be converted to a human-readable string using
   moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_transcribe_stream(
    int32_t transcriber_handle, int32_t stream_handle, uint32_t flags,
    struct transcript_t **out_transcript);

/* ------------------------------ EMBEDDING MODEL --------------------------- */

/* Supported embedding model architectures.                                  */
#define MOONSHINE_EMBEDDING_MODEL_ARCH_GEMMA_300M (0)

/* Creates an embedding model from files on disk.

   `model_path` should be the path to the directory containing the embedding
   model files (ONNX model and tokenizer.bin).

   `model_arch` should be one of the MOONSHINE_EMBEDDING_MODEL_ARCH_* constants.
   Currently only MOONSHINE_EMBEDDING_MODEL_ARCH_GEMMA_300M is supported.

   `model_variant` specifies which model variant to load: "q4" or "q8".
   Pass NULL to use the default "q4" variant. "fp32", "fp16", and "q4f16"
   are no longer supported and return an error.

   Returns a non-negative handle on success, or a negative error code on
   failure. The error code can be converted to a human-readable string using
   moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_create_embedding_model(
    const char *model_path, uint32_t model_arch, const char *model_variant);

/* Creates an embedding model from in-memory model buffers.

   This mirrors moonshine_load_transcriber_from_memory_files and
   moonshine_create_tts_synthesizer_from_memory: `filenames[i]` is the canonical
   asset filename (as listed by moonshine_get_embedding_dependencies, e.g.
   `model_q4.ort` and `tokenizer.bin`) and `memory[i]` / `memory_sizes[i]` are
   the corresponding bytes. The embedding model must be a single self-contained
   all-in-one `.ort` file (no external-data sidecar); the tokenizer is
   `tokenizer.bin`. The library copies the bytes it needs, so the buffers only
   need to remain valid for the duration of this call.

   `model_arch` should be one of the MOONSHINE_EMBEDDING_MODEL_ARCH_* constants.
   `model_variant` selects the variant ("q4", "q8";
   NULL defaults to "q4") and is only used to pick the model file when the
   filename keys do not make it unambiguous. "fp32", "fp16", and "q4f16" are
   no longer supported.

   Returns a non-negative handle on success, or a negative error code on
   failure.
*/
MOONSHINE_EXPORT int32_t moonshine_create_embedding_model_from_memory(
    uint32_t model_arch, const char *model_variant, const char **filenames,
    uint64_t filenames_count, const uint8_t **memory,
    const uint64_t *memory_sizes, const struct moonshine_option_t *options,
    uint64_t options_count, int32_t moonshine_version);

/* Frees an embedding model and all its resources. */
MOONSHINE_EXPORT void moonshine_free_embedding_model(
    int32_t embedding_model_handle);

/* Calculates the embedding for a given sentence.

   On success, ``*out_embedding`` is set to a heap-allocated array of floats and
   ``*out_embedding_size`` is set to the number of elements. Release the array
   with ``moonshine_free_embedding``.

   Returns zero on success, or a non-zero error code on failure.
*/
MOONSHINE_EXPORT int32_t moonshine_calculate_embedding(
    int32_t embedding_model_handle, const char *sentence, float **out_embedding,
    uint64_t *out_embedding_size, const char *model_name);

/* Frees an embedding returned by moonshine_calculate_embedding. */
MOONSHINE_EXPORT void moonshine_free_embedding(float *embedding);

/* Calculates the cosine similarity between two embedding vectors.

   Both ``embedding_a`` and ``embedding_b`` must have ``embedding_size``
   elements.  The result is written to ``*out_similarity`` and is in the
   range [-1, 1] (1 = identical, 0 = orthogonal, -1 = opposite).

   Returns zero on success, or a non-zero error code on failure.
*/
MOONSHINE_EXPORT int32_t moonshine_calculate_embedding_distance(
    int32_t embedding_model_handle, const float *embedding_a,
    const float *embedding_b, uint64_t embedding_size, float *out_similarity);

/* ------------------------------ SPEECH CLIPS --------------------------- */

/* A short window of mostly-speech audio pulled out of a longer recording,
   returned by moonshine_extract_speech_clip. */
struct moonshine_speech_clip_t {
  /* 16 kHz mono PCM. NULL unless ``is_complete`` is non-zero. Allocated with
     malloc; release with moonshine_free_buffer. */
  float *audio_data;
  uint64_t audio_length;
  /* Where the window starts in the input recording, in seconds. */
  float start_time;
  /* How much of the window is speech, in seconds. Useful for showing progress
     while the caller is still recording. */
  float speech_duration;
  /* Non-zero once a window with enough speech in it was found. */
  int32_t is_complete;
  /* UTF-8 transcript of the clip when the TTS synthesizer owns a clone ASR
     and the window was complete enough to refine. NULL otherwise. Allocated
     with malloc; release with moonshine_free_buffer. */
  char *transcript;
};

/* Finds the best short window of speech in a recording, for use as the
   reference clip in zero-shot voice cloning.

   ``tts_synthesizer_handle`` must be a valid synthesizer from
   ``moonshine_create_tts_synthesizer_*``. The call always runs the built-in
   voice-activity detector (no download) over ``audio_data``, slides a window
   of ``clip_duration_seconds`` across the result, and returns the window with
   the most speech. If no window contains at least ``minimum_speech_seconds``
   of speech, ``out_clip->is_complete`` is zero and no audio is returned; the
   caller should record more and call again (streaming capture).

   Extract is VAD-only and stays cheap enough for the capture loop. When
   ZipVoice is later created without ``zipvoice_clone_transcript``, the owned
   clone ASR (from ``g2p_root/clone_asr/`` or ``clone_asr/...`` memory keys)
   refines the clip and fills the transcript once — see
   ``moonshine_get_tts_dependencies``.

   The returned clip is always 16 kHz mono regardless of ``sample_rate``.

   Recognised ``options``:
     ``clip_duration_seconds``  length of the window (default 4).
     ``minimum_speech_seconds`` speech required in it (default 2).
     ``vad_threshold``          speech probability threshold (default 0.5).
     ``tail_pad_seconds``       extra audio after the VAD window (default 0).

   Returns zero on success, or a non-zero error code on failure. The error code
   can be converted to a human-readable string using moonshine_error_to_string.
*/
MOONSHINE_EXPORT int32_t moonshine_extract_speech_clip(
    const float *audio_data, uint64_t audio_length, int32_t sample_rate,
    int32_t tts_synthesizer_handle, const struct moonshine_option_t *options,
    uint64_t options_count, struct moonshine_speech_clip_t *out_clip);

/* ------------------------------ TEXT TO SPEECH ------------------------- */

/* Creates a text to speech synthesizer from files on disk.
   Returns a non-negative handle on success, or a non-zero error code on
   failure. The error code can be converted to a human-readable string using
   moonshine_error_to_string.
   Pass option ``voice`` as ``kokoro_<id>`` or ``piper_<stem>`` to select the
   vocoder, or as a bare Kokoro id / Piper stem when using the default auto
   choice (and other TTS paths via ``moonshine_option_t`` as documented for
   ``MoonshineTTSOptions``). ``engine`` / ``vocoder_engine`` options are
   ignored.

   ZipVoice (zero-shot voice cloning) is selected with ``voice`` =
   ``zipvoice_<id>`` for a built-in VCTK reference voice (e.g.
   ``zipvoice_american_female``, ``zipvoice_indian_male``), or a bare
   ``zipvoice`` together with a caller-supplied reference clip via
   ``moonshine_create_tts_synthesizer_from_memory`` (key
   ``zipvoice/clone_audio``). ZipVoice model assets
   (``zipvoice/text_encoder.ort``, ``zipvoice/fm_decoder.ort``,
   ``zipvoice/vocoder.ort``, ``zipvoice/tokens.txt``,
   ``zipvoice/model.json``) are resolved under ``g2p_root`` or supplied in
   memory. English only for now.

   For ZipVoice cloning, download TTS dependencies (including the
   ``role":"clone_asr"`` group) under ``g2p_root`` so ``g2p_root/clone_asr/``
   holds the catalog STT, or pass ``clone_asr/<stt-filename>`` memory keys to
   ``moonshine_create_tts_synthesizer_from_memory``. The library owns that ASR
   for the synthesizer lifetime and uses it inside
   ``moonshine_extract_speech_clip``. When a caller-supplied
   ``zipvoice/clone_audio`` clip has no ``zipvoice_clone_transcript``, the clip
   is refined with that ASR at create time.

   Phonon (Gradium's 31M-parameter autoregressive English model,
   https://huggingface.co/gradium/phonon-31m-en, Apache 2.0, built on Kyutai's
   Pocket TTS and Mimi codec) is selected with ``voice`` = ``phonon_<id>`` for
   a catalog voice listed in ``phonon/voices.json`` (e.g. ``phonon_zoey``; the
   catalog is Gradium's Apache 2.0 ``phonon-voices`` set), or a bare ``phonon``
   with a caller-supplied voice file under key ``phonon/voice`` (a Phonon
   ``.safetensors`` of speaker latents, such as a voice designed or cloned in
   Gradium's hosted Studio and downloaded for Phonon; the speaker encoder is
   not published, so on-device cloning is ZipVoice only). Model assets are the
   six
   ``phonon/<graph>.ort`` files, ``phonon/model.json``, ``phonon/tokenizer.bin``
   and
   ``phonon/voices/<id>.safetensors``. Options: ``phonon_temperature`` (0 is
   deterministic; default 0.3), ``phonon_seed``, ``phonon_duration_delta``
   (direct duration conditioning, positive is slower; otherwise derived from
   ``speed``), ``phonon_normalize_text``. Phonon reads text, so
   ``moonshine_phonemes_to_speech`` is refused for it. Streaming cuts on
   generated frames rather than planned ones, so the first chunk arrives after
   roughly ``stream_first_chunk_seconds`` of audio has been generated.
*/
MOONSHINE_EXPORT int32_t moonshine_create_tts_synthesizer_from_files(
    const char *language, const char **filenames, uint64_t filenames_count,
    const struct moonshine_option_t *options, uint64_t options_count,
    int32_t moonshine_version);

/* Creates a text to speech synthesizer from memory.
   Returns a non-negative handle on success, or a non-zero error code on
   failure. The error code can be converted to a human-readable string using
   moonshine_error_to_string.

   ``filenames[i]`` is the canonical ``MoonshineTTSOptions::files`` key (e.g.
   ``kokoro/prosody.model.ort``, ``kokoro/prosody.weights.ort``,
   ``kokoro/decoder.model.ort``, ``kokoro/decoder.weights.ort``,
   ``kokoro/config.json``, ``kokoro/voices/af_heart.kokorovoice``,
   ``piper/onnx``, ``piper/onnx.json``, ``zipvoice/text_encoder.ort``,
   ``zipvoice/fm_decoder.ort``, ``zipvoice/vocoder.ort``,
   ``zipvoice/tokens.txt``, ``zipvoice/model.json``). For ZipVoice a
   caller-supplied reference clip is passed as key ``zipvoice/clone_audio``
   (raw little-endian float32 mono PCM); set ``zipvoice_clone_sample_rate`` and,
   optionally, ``zipvoice_clone_transcript``. When the transcript is omitted,
   supply ``clone_asr/<stt-filename>`` keys (from the ZipVoice TTS dependency
   ``clone_asr`` group) so the library can refine and auto-transcribe the clip
   with its owned ASR. When ``memory[i]`` is non-NULL and
   ``memory_sizes[i]`` > 0, that buffer is used as the asset bytes; the library
   does not copy it—keep the buffers valid until
   ``moonshine_free_tts_synthesizer``. When ``memory[i]`` is NULL or
   ``memory_sizes[i]`` is zero, the key string is also used as a path relative
   to ``g2p_options.g2p_root`` (from ``options``), same as path-only map
   entries.

   Other ``options`` are parsed like
   ``moonshine_create_tts_synthesizer_from_files``.
*/
MOONSHINE_EXPORT int32_t moonshine_create_tts_synthesizer_from_memory(
    const char *language, const char **filenames,
    const uint64_t filenames_count, const uint8_t **memory,
    const uint64_t *memory_sizes, const struct moonshine_option_t *options,
    uint64_t options_count, int32_t moonshine_version);

/* Releases the resources used by a text to speech synthesizer. */
MOONSHINE_EXPORT void moonshine_free_tts_synthesizer(
    int32_t tts_synthesizer_handle);

/* Returns G2P-only canonical asset keys for one or more languages.
   ``languages`` is comma-separated CLI tags (same as ``moonshine_create_*``
   ``language``); an empty string (or NULL) means all known languages (union of
   keys).
   ``options`` / ``options_count``: same ``moonshine_option_t`` entries as
   grapheme phonemizer / G2P
   (``g2p_root``, ``spanish_narrow_obstruents``, ``oov_onnx_override``, …).
   TTS-only keys
   (``voice``, deprecated ``vocoder_engine`` / ``engine``, Piper/Kokoro paths)
   are ignored here. Non-empty values for in-memory override keys add those
   canonical key names to the list. On success, writes a comma-separated list to
   ``*out_dependencies_json`` and returns
   ``MOONSHINE_ERROR_NONE``. The buffer is allocated with ``malloc``; release
   with ``free``. On failure (e.g. unknown language token), logs and returns a
   non-zero error code and sets
   ``*out_dependencies_json`` to NULL.
*/
MOONSHINE_EXPORT int32_t moonshine_get_g2p_dependencies(
    const char *languages, const struct moonshine_option_t *options,
    uint64_t options_count, char **out_dependencies_json);

/* Returns merged G2P + TTS vocoder download dependencies as a JSON object with
   a ``groups`` array (same shape as ``moonshine_get_stt_dependencies``). Each
   group is ``{ "base_url", "files": [{name,url,size,checksum,checksum_type}]
   }``.
   ``languages`` is comma-separated; empty or NULL means all known languages.
   ``options`` / ``options_count``: same entries as
   ``moonshine_create_tts_synthesizer_from_files``
   (``voice`` with optional ``kokoro_`` / ``piper_`` / ``zipvoice_`` prefix,
   ``g2p_root``, …). Vocoder keys follow Kokoro vs Piper vs ZipVoice selection.

   When ``voice`` selects ZipVoice, an additional group with
   ``"role":"clone_asr"`` lists the catalog-default STT for the language
   (including the attention decoder for word timestamps). Local ``name``s are
   prefixed ``clone_asr/``;
   ``url``s point at the STT CDN. Bindings should download those files under
   ``g2p_root/clone_asr/`` (or pass ``clone_asr/...`` memory keys on create).

   On success, ``*out_dependencies_json`` is a NUL-terminated JSON object; free
   with ``free``.
*/
MOONSHINE_EXPORT int32_t moonshine_get_tts_dependencies(
    const char *languages, const struct moonshine_option_t *options,
    uint64_t options_count, char **out_dependencies_json);

/* Returns known TTS voices for the requested languages with availability state.
   ``languages`` is comma-separated; empty or NULL means all registered catalog
   languages (same tag set as G2P dependencies) that have a resolved TTS layout.
   ``options`` / ``options_count``: same entries as
   ``moonshine_create_tts_synthesizer_from_files``
   (``voice`` prefix selects vocoder for listing; ``vocoder_engine`` /
   ``engine`` are ignored; Piper/Kokoro path overrides). For accurate ``found``
   / ``missing``, set an asset root with
   ``g2p_root`` or the aliases ``path_root``, ``tts_root``, or ``model_root``
   (see
   ``MoonshineTTSOptions::parse_options``). If none are set, the implementation
   uses the process current working directory. Language bindings typically
   default this to their download/cache directory. The ``voice`` option does not
   filter the list.

   On success, ``*out_voices_json`` is a NUL-terminated JSON object mapping each
   language tag to a JSON array of objects ``{"id":"<voice>","state":"found"}``
   or ``{"id":"<voice>","state":"missing"}``. Voice ids are prefixed with
   ``kokoro_`` or ``piper_``. Kokoro uses the upstream Kokoro-82M voice id
   catalog plus any extra ``*.kokorovoice`` in the bundle; Piper lists the
   language default voice stem plus every voice in the resolved voices
   directory, in either shipped form (``<stem>.ort``, or the split
   ``<stem>.model.ort`` plus ``<stem>.weights.ort`` pair). ``found`` means the
   asset is on disk or supplied via the in-memory file map like
   ``MoonshineTTS``. Free with ``free``.
*/
MOONSHINE_EXPORT int32_t moonshine_get_tts_voices(
    const char *languages, const struct moonshine_option_t *options,
    uint64_t options_count, char **out_voices_json);

/* ------------------------------ MODEL DOWNLOAD MANIFESTS ----------------- */

/* Returns the download manifest for a speech-to-text transcription model as a
   JSON object. This lets language bindings and applications fetch exactly the
   files a model needs from the CDN (https://download.moonshine.ai) without
   hardcoding the file layout, then load the model from the resulting
   directory with moonshine_load_transcriber_from_files.

   ``language`` is a language code (for example ``"en"``) or English name (for
   example ``"English"``); it must not be empty.

   ``options`` / ``options_count`` accept the same option list you would pass to
   moonshine_load_transcriber_from_files, so a binding can build one set of
   options and use it both to resolve this manifest and to load the model.
   Options that do not change which files are needed are ignored; the ones that
   do are honored:
     - ``model_arch``: one of the MOONSHINE_MODEL_ARCH_* constants as a decimal
       string. When omitted, the default (first) model for the language is
       used. Note: MOONSHINE_MODEL_ARCH_BASE_STREAMING is defined but not
       currently published in the model catalog.
     - ``word_timestamps`` (bool): when true, the optional attention decoder
       (``decoder_kv_with_attention.ort`` for streaming, or
       ``decoder_with_attention.ort`` for non-streaming) is included for
       languages that publish it. This file is only needed to produce word-level
       timestamps and roughly doubles the download, so it defaults to false.
     - ``include_spelling`` / ``spelling`` (bool), or ``spelling_model_path``
       (non-empty path): when set and a spelling model is published for the
       language, its files are appended as an extra group. Defaults to false.
   Other options are ignored.

   On success, writes a NUL-terminated JSON object to
   ``*out_dependencies_json`` and returns ``MOONSHINE_ERROR_NONE``. The shape
   is:
     ``{"groups":[{"base_url":"https://download.moonshine.ai/model/tiny-en/quantized/tiny-en","files":[{"name":"encoder_model.ort","url":"https://download.moonshine.ai/model/tiny-en/quantized/tiny-en/encoder_model.ort","size":12345,"checksum":"abc==","checksum_type":"crc32c"},
   ...]}]}`` Each entry in ``files`` is an object with ``name`` (canonical
   filename),
   ``url`` (fully-qualified download URL, i.e. ``base_url + "/" + name``),
   ``size`` (bytes, or null when unknown), ``checksum`` (base64 digest, or ""),
   and ``checksum_type`` (e.g. "crc32c", or ""). A model is a single group,
   plus an optional second group for the spelling model (which uses a different
   ``base_url``). The buffer is allocated with ``malloc``; release it with
   ``free``. On failure (empty language, unknown language, or a language that
   does not publish the requested architecture) returns a non-zero error code,
   logs which case it is (listing the architectures that language does publish
   when the language is known), and sets ``*out_dependencies_json`` to NULL. */
MOONSHINE_EXPORT int32_t moonshine_get_stt_dependencies(
    const char *language, const struct moonshine_option_t *options,
    uint64_t options_count, char **out_dependencies_json);

/* Returns the download manifest for an embedding model as a JSON object with
   the same shape as moonshine_get_stt_dependencies. Load the downloaded
   directory with moonshine_create_embedding_model.

   ``model_name`` is an embedding model id (for example
   ``"embeddinggemma-300m"``); pass NULL or an empty string to use the default
   model.

   ``options`` / ``options_count`` recognize ``variant`` (aliases:
   ``model_variant``): one of ``"q4"`` or ``"q8"``. ``"fp32"``, ``"fp16"``,
   and ``"q4f16"`` are no longer supported. When omitted, the model's
   default variant is used. Other
   options are ignored. The manifest lists the single all-in-one model file
   (``model_<variant>.ort``) and ``tokenizer.bin``.

   On success, writes a NUL-terminated JSON object to
   ``*out_dependencies_json`` (single group, same file-object shape as
   moonshine_get_stt_dependencies) and returns ``MOONSHINE_ERROR_NONE``; free
   with ``free``. On failure (unknown model or variant) returns a non-zero
   error code and sets ``*out_dependencies_json`` to NULL. */
MOONSHINE_EXPORT int32_t moonshine_get_embedding_dependencies(
    const char *model_name, const struct moonshine_option_t *options,
    uint64_t options_count, char **out_dependencies_json);

/* Returns the download manifest for the speaker diarization models as a JSON
   object with the same shape as moonshine_get_stt_dependencies. Fetch these
   whenever you intend to pass ``identify_speakers=true`` to a transcriber, and
   point the transcriber at them with the ``diarization_model_dir`` option (or
   supply them as ``segmentation.ort`` / ``embedding.ort`` entries to
   moonshine_load_transcriber_from_memory_files).

   There is one set of diarization models and it has no variants, so this takes
   no arguments beyond the output pointer. The manifest is a single group of two
   files totalling about 8.2 MB.

   These models were compiled into the library before version 26.8; a
   transcriber built with ``identify_speakers=true`` and no diarization models
   now fails to load rather than falling back. See docs/diarization-models.md.

   The buffer is allocated with ``malloc``; release it with ``free``. Returns
   ``MOONSHINE_ERROR_NONE`` on success. */
MOONSHINE_EXPORT int32_t
moonshine_get_diarization_dependencies(char **out_dependencies_json);

/* Returns the full speech-to-text model catalog as a JSON object, so bindings
   can build language/model pickers and resolve defaults without their own copy
   of the tables. The shape is:
     ``{"languages":[{"code":"en","english_name":"English","models":[{"model_arch":9,"download_url":"https://...","is_default":true},
   ...]}, ...]}`` The buffer is allocated with ``malloc``; release it with
   ``free``. Returns
   ``MOONSHINE_ERROR_NONE`` on success. */
MOONSHINE_EXPORT int32_t moonshine_get_stt_catalog(char **out_catalog_json);

/* Returns the full text embedding model catalog as a JSON object.
   The shape is:
     ``{"models":[{"name":"embeddinggemma-300m","english_name":"Embedding Gemma
   300M","download_url":"https://...","variants":["q4",
   ...],"default_variant":"q4"}]}`` The buffer is allocated with ``malloc``;
   release it with ``free``. Returns
   ``MOONSHINE_ERROR_NONE`` on success. */
MOONSHINE_EXPORT int32_t
moonshine_get_embedding_catalog(char **out_catalog_json);

/* Synthesizes text to speech.
   ``options`` / ``options_count``: optional per-call overrides using the same
   ``name`` / ``value`` convention as the synthesizer constructor. Currently
   only
   ``speed`` is honored for the duration of this call (Kokoro ONNX input and
   Piper length scale); other entries are ignored. Pass NULL / 0 to use the
   synthesizer default speed from construction.

   Returns zero on success, or a non-zero error code on failure.
*/
MOONSHINE_EXPORT int32_t moonshine_text_to_speech(
    int32_t tts_synthesizer_handle, const char *text,
    const struct moonshine_option_t *options, uint64_t options_count,
    float **out_audio_data, uint64_t *out_audio_data_size,
    int32_t *out_sample_rate);

/* Synthesizes speech directly from International Phonetic Alphabet (IPA)
   phonemes, skipping the grapheme-to-phoneme conversion that
   ``moonshine_text_to_speech`` performs internally. ``phonemes`` should be an
   IPA string in the same format produced by ``moonshine_text_to_phonemes`` (a
   grapheme-to-phonemizer created for the matching language). This lets callers
   inspect or edit the phonemes between the text-to-phonemes and
   phonemes-to-speech steps (e.g. to fix pronunciation of a name). The
   phonemes are normalized to the active vocoder's phoneme inventory before
   synthesis, so passing the raw ``moonshine_text_to_phonemes`` output for the
   same language yields audio equivalent to ``moonshine_text_to_speech`` on the
   original text.

   ``options`` / ``options_count`` behave exactly like
   ``moonshine_text_to_speech``: only ``speed`` is honored for the duration of
   the call; pass NULL / 0 to use the synthesizer defaults.

   Returns zero on success, or a non-zero error code on failure.
*/
MOONSHINE_EXPORT int32_t moonshine_phonemes_to_speech(
    int32_t tts_synthesizer_handle, const char *phonemes,
    const struct moonshine_option_t *options, uint64_t options_count,
    float **out_audio_data, uint64_t *out_audio_data_size,
    int32_t *out_sample_rate);

/* --------------------------- STREAMING TEXT TO SPEECH -------------------- */

/* Splits a passage into the utterances a streaming synthesizer would speak one
   at a time. Exposed on its own so a caller can queue work itself, or show the
   same boundaries in a UI that the audio will follow.

   ``language`` is the same tag as ``moonshine_create_tts_synthesizer_*``; it
   selects the abbreviation list ("Dr." and "z.B." do not end a sentence) and
   the terminators that count (``。！？`` need no trailing space, ``;`` is a
   question mark only in Greek). NULL or empty applies the language-neutral
   rules.

   Recognised ``options``:
     ``split_on_colon``  (bool, default true) break after ":" so a lead-in like
                         "Warning:" starts playing before the rest is
                         synthesized.
     ``min_codepoints``  (int, default 0) merge a unit shorter than this into
                         the next one, so a stray "Hi." is not spoken alone.

   On success ``*out_units_json`` is a NUL-terminated JSON array of strings;
   release it with ``moonshine_free_buffer``. An empty or whitespace-only input
   gives ``[]``. */
MOONSHINE_EXPORT int32_t
moonshine_tts_split_utterances(const char *language, const char *text,
                               const struct moonshine_option_t *options,
                               uint64_t options_count, char **out_units_json);

/* One piece of synthesized audio from a streaming session. Owned by the
   synthesizer and valid only until the next call on the same stream, the same
   convention transcript_t uses. Copy anything you need to keep. */
struct tts_chunk_t {
  /* Mono PCM in [-1, 1]. Never NULL when a chunk was returned. */
  const float *audio_data;
  uint64_t audio_data_count;
  int32_t sample_rate;
  /* The text this chunk covers, or "" when the engine cut on acoustic frames
     rather than a knowable span of characters (only the first chunk of such an
     utterance carries text). */
  const char *text;
  /* Which queued utterance this came from, counting from 1. Lets a consumer
     tell where one reply ends and the next begins without tracking flushes. */
  uint64_t utterance_id;
  /* Non-zero on the last chunk of an utterance. */
  int8_t is_final;
};

/* Streaming synthesis on ``tts_synthesizer_handle``.

   Pull-based and synchronous: text goes in with ``moonshine_tts_push_text`` as
   it becomes available, and audio comes out of ``moonshine_tts_next_chunk`` a
   chunk at a time. No thread is created and no callback is invoked, so a
   binding can drive it from whatever worker suits its platform.

   There is no session object. A synthesizer runs one generation at a time:
   pushing text starts one, ``moonshine_tts_end_input`` finishes it, and
   ``moonshine_tts_cancel`` abandons it. While one is in flight the one-shot
   ``moonshine_tts_synthesize`` returns ``MOONSHINE_ERROR_BUSY`` rather than
   competing for the model. Calls are internally serialized, so driving the
   stream from a worker thread is safe; they block each other.

   How much audio a chunk holds depends on the engine. Kokoro cuts inside a
   sentence where its prosody/decoder stages are installed, which starts
   playback sooner; everything else emits one chunk per sentence, which still
   starts on the first clause rather than the last. */

/* Appends text. Pieces are concatenated verbatim, so feeding an LLM's output
   token by token reassembles the words correctly. Starts a generation if none
   is running.

   Text is held back until it forms a complete utterance, because synthesizing
   half a sentence gets the prosody wrong. Anything left over waits for the
   next push, a ``moonshine_tts_flush``, or ``moonshine_tts_end_input``.

   Returns ``MOONSHINE_ERROR_NONE`` on success. */
MOONSHINE_EXPORT int32_t moonshine_tts_push_text(int32_t tts_synthesizer_handle,
                                                 const char *text);

/* Queues whatever text is buffered even though it does not look like a
   complete sentence. Use it where the caller knows the thought is finished but
   the punctuation does not say so. */
MOONSHINE_EXPORT int32_t moonshine_tts_flush(int32_t tts_synthesizer_handle);

/* Declares that no more text is coming. Flushes, then makes
   ``moonshine_tts_next_chunk`` report ``MOONSHINE_TTS_END_OF_STREAM`` once the
   queue drains, which also returns the synthesizer to idle. */
MOONSHINE_EXPORT int32_t
moonshine_tts_end_input(int32_t tts_synthesizer_handle);

/* Drops queued text, abandons the generation in progress and returns the
   synthesizer to idle. This is the barge-in path: when someone interrupts the
   assistant, stop the reply. Safe to call when nothing is streaming. */
MOONSHINE_EXPORT int32_t moonshine_tts_cancel(int32_t tts_synthesizer_handle);

/* Non-zero while a streaming generation is in flight. */
MOONSHINE_EXPORT int32_t
moonshine_tts_is_streaming(int32_t tts_synthesizer_handle);

/* Produces the next chunk of audio, synthesizing it during the call.

   This never waits on another thread: it blocks only for as long as the model
   takes, and returns immediately when there is nothing to do. ``flags`` is
   reserved and must be 0. The returned chunk is owned by the synthesizer and
   is valid only until the next call on it.

   Returns ``MOONSHINE_ERROR_NONE`` with ``*out_chunk`` set when a chunk was
   produced, ``MOONSHINE_TTS_NEED_TEXT`` when no complete utterance is buffered
   (push more, or flush), ``MOONSHINE_TTS_END_OF_STREAM`` after
   ``moonshine_tts_end_input`` and the queue has drained,
   ``MOONSHINE_TTS_CANCELLED`` once after ``moonshine_tts_cancel`` discarded a
   reply, or a negative error code. ``*out_chunk`` is set to NULL for every
   non-success status. */
MOONSHINE_EXPORT int32_t
moonshine_tts_next_chunk(int32_t tts_synthesizer_handle, uint32_t flags,
                         const struct tts_chunk_t **out_chunk);

/* Creates a grapheme to phonemizer from files on disk.
   Returns a non-negative handle on success, or a negative error code on
   failure. The error code can be converted to a human-readable string using
   moonshine_error_to_string.

   Lexicons and bundled ONNX assets are resolved under ``g2p_root`` (or the
   process current working directory when ``g2p_root`` / ``model_root`` is
   unset) using the same canonical relative keys as
   ``MoonshineG2POptions::files`` in the C++ API (for example
   ``en_us/dict_filtered_heteronyms.tsv``,
   ``zh_hans/roberta_chinese_base_upos_onnx/meta.json``,
   ``zh_hans/roberta_chinese_base_upos_onnx/model.model.ort``,
   ``en_us/g2p-config.json``, ``en_us/oov/model.ort``,
   ``en_us/oov/onnx-config.json``). Japanese and Arabic tok-POS / diacritizer
   bundles use the same pattern under ``ja/...`` and
   ``ar_msa/...``. Korean rule G2P uses ``ko/dict.tsv`` only. Models that ship
   as a split ORT pair need both ``<stem>.model.ort`` and
   ``<stem>.weights.ort`` present.

   Every model is ORT-format. Moonshine cannot load a ``.onnx``: the wasm and
   mobile runtimes are minimal ONNX Runtime builds with no ONNX parser
   compiled in. Convert one with ``scripts/convert-models-to-ort.py``.
*/
MOONSHINE_EXPORT int32_t moonshine_create_grapheme_to_phonemizer_from_files(
    const char *language, const char **filenames, uint64_t filenames_count,
    const struct moonshine_option_t *options, uint64_t options_count,
    int32_t moonshine_version);

/* Creates a grapheme to phonemizer from memory.
   Returns a non-negative handle on success, or a negative error code on
   failure. The error code can be converted to a human-readable string using
   moonshine_error_to_string.

   ``filenames[i]`` is the canonical ``MoonshineG2POptions::files`` key.
   When ``memory[i]`` is non-NULL and ``memory_sizes[i]`` > 0, that buffer is
   used as the asset bytes (not copied—keep valid until the phonemizer is
   freed). When ``memory[i]`` is NULL or size zero, the key is also used as a
   path relative to ``g2p_root``, like path-only map entries.

   Register every file the engine needs: language lexicon ``dict.tsv`` paths,
   English ``g2p-config.json`` and the OOV model keys under ``en_us/oov/``, and
   for model bundles the ``meta.json``, ``vocab.txt``,
   ``tokenizer_config.json``, and ``model.ort`` keys under the bundle directory
   key (or both halves of a split pair). English OOV overrides use
   ``oov_onnx_override`` for the model bytes and ``oov_onnx_config`` for the
   merged JSON config UTF-8 text; those key names predate the move to ORT and
   are kept for compatibility, but the bytes must be ORT-format.

   Every model buffer must be a self-contained ORT model. Moonshine cannot
   load a ``.onnx``, and there is no support for a sidecar weights file:
   convert with ``scripts/convert-models-to-ort.py``.
*/
MOONSHINE_EXPORT int32_t moonshine_create_grapheme_to_phonemizer_from_memory(
    const char *language, const char **filenames,
    const uint64_t filenames_count, const uint8_t **memory,
    const uint64_t *memory_sizes, const struct moonshine_option_t *options,
    uint64_t options_count, int32_t moonshine_version);

/* Releases the resources used by a grapheme to phonemizer. */
MOONSHINE_EXPORT void moonshine_free_grapheme_to_phonemizer(
    int32_t grapheme_to_phonemizer_handle);

/* Converts a text into the equivalent International Phonetic Alphabet (IPA)
   phonemes. Returns zero on success, or a non-zero error code on failure.
*/
MOONSHINE_EXPORT int32_t moonshine_text_to_phonemes(
    int32_t grapheme_to_phonemizer_handle, const char *text,
    const struct moonshine_option_t *options, uint64_t options_count,
    const char **out_phonemes, uint64_t *out_phonemes_count);

#ifdef __cplusplus
}
#endif

#endif
